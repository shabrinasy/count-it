<?php

namespace App\Filament\Widgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;
use Illuminate\Support\Facades\DB;

class PembelianOverview extends BaseWidget
{
    protected function getStats(): array
    {
        $purchase = DB::table('purchase_items')
        ->join('purchases', 'purchases.id', '=', 'purchase_items.purchases_id')
        ->whereMonth('purchases.date', now()->month)
        ->sum(DB::raw('purchase_items.quantity * purchase_items.price'));
        $previousMonthPurchase = DB::table('purchase_items')
        ->join('purchases', 'purchases.id', '=', 'purchase_items.purchases_id')
        ->whereMonth('purchases.date', now()->subMonth()->month)
        ->sum(DB::raw('purchase_items.quantity * purchase_items.price'));

        if ($purchase > $previousMonthPurchase) {
            $description = number_format($purchase - $previousMonthPurchase, 0, ',', '.').' increase';
            $icon = 'heroicon-m-arrow-trending-up';
            $color = 'success';
        } elseif ($purchase < $previousMonthPurchase) {
            $description = number_format($previousMonthPurchase - $purchase, 0, ',', '.').' decrease';
            $icon = 'heroicon-m-arrow-trending-down';
            $color = 'danger';
        } else {
            $description = 'increase but 0';
            $icon = 'heroicon-m-arrow-trending-up';
            $color = 'success';
        }
        return [
            Stat::make('Total Pembelian Bulan ini', 'Rp. ' . number_format($purchase, 0, ',', '.'))
                ->description($description)
                ->descriptionIcon($icon)
                ->color($color),
        ];
    }
}
